# Getting Started with AXA Design System Lib

This project is a re-write of the famous Bootsrap library

## Available Scripts in Root folder

In the root project directory, you can run:

### `npm ci`

Install all required node modules

### `npm run css`

Builds the css and minified css library files to folder dist/designsystem@x.x.x/css (where x.x.x is the version setupped in the package.json)

### `npm run js`

Copy the js files that the library depends on into folder [dist/designsystem@x.x.x/js] (bootstrap.js, jquery.js and popper.js)

### `npm run fonts`

copy fonts required for the library into folder [dist/designsystem@x.x.x/fonts]

### `npm run create-zipdist`

compress in zip format the downloadable current distribution ([dist/designsystem@x.x.x]) and copy it to the folder [downloadfiles] (with other shared elements as figma & sketch files). 

### `npm run create-sources`

copy the whole project sources in the distribution folder ([dist/sources/designsystem_sources@x.x.x]). 

### `npm run create-zip-sources`

compress in zip format the downloadable sources distribution ([dist/sources/designsystem_sources@x.x.x]) and copy it to the folder [downloadfiles] (with other shared elements). 

### `npm run dev`

Runs the current documentation libray website
Open [http://localhost:1234](http://localhost:1234) to view it in the browser.

The page will reload if you make edits (html, js, saas files, etc.).\

The zip files must be firstly created in folder [downloadfiles] before executiong this command.

### `npm run html:build`

Builds the documentation library website for production mode in the folder www/build (folder is cleaned before building)
Open [http://localhost:1234](http://localhost:1234) to view it in the browser.

The page will reload if you make edits (html, js, saas files, etc.).

> #### before executiong this command :
> - As Publico Headline Bold font is commercial, you must purshase it and put the font files in woff & woff2 format in folder [fonts] with correct name => [fonts/PublicoHeadline-Bold.woff] & [fonts/PublicoHeadline-Bold.woff2]
> 
> - The zip files (`npm run create-zipdist` & `npm run create-zip-sources`) must be firstly created in folder [downloadfiles].

### `npm run copy-htmlbuild-to-showcase`

copy the build of the documentation library website in the virtual directory of the showcase website server [showcase-website/server/dist/docs/vx.x]

## Notes

**Note 1: when a new version of the library is created don't forget to add/update version reference and download links in files [package.json], [www/index.html]and [scss/axaDesignSystemLib.scss]**

**Note 2: the folder [showcase-website/server/dist/docs/vx.x.x] is commited in the git repository to keep history of the library in the showcase website**

**Note 3: to build the library and create a release documentation launch the following scripts in order and open documentation here [www/build/index.html]**
### `npm run css`
### `npm run js`
### `npm run fonts`
### `npm run create-zipdist`
### `npm run create-sources`
### `npm run create-zip-sources`
### `npm run html:build`

**Note 4: cross-var limitation : because of a bug in cross-var you should not have one of your parent folder containing string "src", take care on that limitation when trying to run scripts in a folder containing this string**

**Note 5: As Publico Headline Bold font is commercial, you must purshase it and put the font in woff & woff2 format in folder [fonts] with correct name => [fonts/PublicoHeadline-Bold.woff] & [fonts/PublicoHeadline-Bold.woff2]**