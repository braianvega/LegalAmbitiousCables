import $ from "jquery";
import * as bootstrap from "bootstrap";

$(function () {
  $("#liveToastBtn").on("click", function () {
  console.log('this is the toast not appearing')
  $("#liveToast").toast("show");
});
$("#basictoast .toast").toast({ autohide: false }).toast("show");
});

$(function () {
  console.log('this is the popover appearing')
  $('[data-toggle="popover"]').popover();
  $(".tooltip-demo").tooltip();
});

$("#FormControlSelectVersionLib").change(function () {
  var option = $(this).find('option:selected');
  window.location.href = "/docs/v"+ encodeURIComponent(option.val());
});