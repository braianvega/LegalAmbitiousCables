import * as axalib from "./axaDesignSystemLib";
// import * as prismjs from "../node_modules/prismjs/prism"

// Enable toast
var toastTrigger = document.getElementById('liveToastBtn')
var toastLiveExample = document.getElementById('liveToast')
if (toastTrigger) {
  toastTrigger.addEventListener('click', function () {
    var toast = new axalib.Toast(toastLiveExample)

    toast.show()
  })
}

// Enable tooltips everywhere
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new axalib.Tooltip(tooltipTriggerEl)
})

// Enable popover everywhere
var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
  return new axalib.Popover(popoverTriggerEl)
})

// var compoCollapse = document.getElementById('components_collapse')
// document.addEventListener('click', function (event) {
//   // alert(event.target.matches('.nav-link.text-capitalize'));
//   if (event.target.matches('.nav-link.text-capitalize'))
//     alert(event.target);
// }) 