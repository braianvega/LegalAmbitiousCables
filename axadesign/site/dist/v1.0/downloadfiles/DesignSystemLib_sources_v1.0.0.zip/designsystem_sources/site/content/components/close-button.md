---
layout: components
title: Close-button
description: Bootstrap is supported by an extensive color system that themes our styles and components. This enables more comprehensive customization and extension for any project. 
---

<div id="components_close_button">
<h3 class="text-muted">components</h3>
<div class="display-3 py-3 text-capitalize">close button</div>
<p class="lead text-justify pe-md-8 pe-lg-11">
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam
  molestiae, atque ad sapiente, numquam explicabo dolor rerum
  perspiciatis laborum perferendis molestias iste eaque cum veniam
  deleniti fugit! Voluptatum, minus. Quas!
</p>
</div>
