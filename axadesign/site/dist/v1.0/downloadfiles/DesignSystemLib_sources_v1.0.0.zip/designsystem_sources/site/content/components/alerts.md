---
layout: components
title: Alerts
description: "An alert displays an important, succinct message, and provides actions for users to address (or dismiss the banner). It requires a user action to be dismissed.  <br>
Alerts should be displayed at the top of the screen, below a top app bar. They’re persistent and nonmodal, allowing the user to either ignore them or interact with them at any time. Only one banner should be shown at a time." 
section: Components
bootstrapRef : https://getbootstrap.com/docs/5.1/components/alerts/
menuSlug: alerts
--- 
  
  <div class="display-5 pt-md-8 pb-1">Examples</div>
  <p class="text-justify pe-md-8 pe-lg-11 pb-3">
    You can use the default colour scheme of the design system
    depending on the type of alert to be displayed.
  </p>
  <div class="ax-example p-md-3 border text-center">
    <div class="alert alert-primary" role="alert">
      A simple primary alert—check it out!
    </div>
    <div class="alert alert-secondary" role="alert">
      A simple secondary alert—check it out!
    </div>
    <div class="alert alert-success" role="alert">
      A simple success alert—check it out!
    </div>
    <div class="alert alert-danger" role="alert">
      A simple danger alert—check it out!
    </div>
    <div class="alert alert-warning" role="alert">
      A simple warning alert—check it out!
    </div>
    <div class="alert alert-info" role="alert">
      A simple info alert—check it out!
    </div>
    <div class="alert alert-light" role="alert">
      A simple light alert—check it out!
    </div>
    <div class="alert alert-dark" role="alert">
      A simple dark alert—check it out!
    </div>
    <div class="alert text-white bg-axa-teal" role="alert">
      A simple custom theme color alert—check it out!
    </div>
  </div>
  <div class="pb-4">

  ```html
  <div class="alert alert-primary" role="alert">
    A simple primary alert—check it out!
  </div>
  <div class="alert alert-secondary" role="alert">
    A simple secondary alert—check it out!
  </div>
  <div class="alert alert-success" role="alert">
    A simple success alert—check it out!
  </div>
  <div class="alert alert-danger" role="alert">
    A simple danger alert—check it out!
  </div>
  <div class="alert alert-warning" role="alert">
    A simple warning alert—check it out!
  </div>
  <div class="alert alert-info" role="alert">
    A simple info alert—check it out!
  </div>
  <div class="alert alert-light" role="alert">
    A simple light alert—check it out!
  </div>
  <div class="alert alert-dark" role="alert">
    A simple dark alert—check it out!
  </div>
  <div class="alert text-white bg-axa-teal" role="alert">
    A simple custom theme color alert—check it out!
  </div> 
  ``` 
  </div> 

  <div class="display-5 pt-md-8 pb-1">With icons</div>
  <p class="text-justify pe-md-8 pe-lg-11 pb-3">
    If you need to reinforce the type of alert, you can place an
    icon next to the text.
  </p>
  <div class="ax-example p-md-3 border text-center">
    <div class="alert alert-primary" role="alert">
      <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
      primary alert—check it out!
    </div>
    <div class="alert alert-secondary" role="alert">
      <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
      secondary alert—check it out!
    </div>
    <div class="alert alert-success" role="alert">
      <i class="icon-check_circle valign-btn-icon fs-xl me-3"></i>A
      simple success alert—check it out!
    </div>
    <div class="alert alert-danger" role="alert">
      <i class="icon-warning valign-btn-icon fs-xl me-3"></i>A
      simple danger alert—check it out!
    </div>
    <div class="alert alert-warning" role="alert">
      <i class="icon-error_outline valign-btn-icon fs-xl me-3"></i>A
      simple warning alert—check it out!
    </div>
    <div class="alert alert-info" role="alert">
      <i class="icon-info valign-btn-icon fs-xl me-3"></i>A simple
      info alert—check it out!
    </div>
    <div class="alert alert-light" role="alert">
      <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
      light alert—check it out!
    </div>
    <div class="alert alert-dark" role="alert">
      <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
      dark alert—check it out!
    </div>
    <div class="alert text-white bg-axa-teal" role="alert">
      <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
      custom theme color alert—check it out!
    </div>
  </div>
  <div class="pb-4">

  ```html 
  <div class="alert alert-primary" role="alert">
    <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
    primary alert—check it out!
  </div>
  <div class="alert alert-secondary" role="alert">
    <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
    secondary alert—check it out!
  </div>
  <div class="alert alert-success" role="alert">
    <i class="icon-check_circle valign-btn-icon fs-xl me-3"></i>A
    simple success alert—check it out!
  </div>
  <div class="alert alert-danger" role="alert">
    <i class="icon-warning valign-btn-icon fs-xl me-3"></i>A
    simple danger alert—check it out!
  </div>
  <div class="alert alert-warning" role="alert">
    <i class="icon-error_outline valign-btn-icon fs-xl me-3"></i>A
    simple warning alert—check it out!
  </div>
  <div class="alert alert-info" role="alert">
    <i class="icon-info valign-btn-icon fs-xl me-3"></i>A simple
    info alert—check it out!
  </div>
  <div class="alert alert-light" role="alert">
    <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
    light alert—check it out!
  </div>
  <div class="alert alert-dark" role="alert">
    <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
    dark alert—check it out!
  </div>
  <div class="alert text-white bg-axa-teal" role="alert">
    <i class="icon-add valign-btn-icon fs-xl me-3"></i>A simple
    custom theme color alert—check it out!
  </div>
  ```
  </div> 

  <div class="display-5 pt-md-8 pb-1">With buttons</div>
  <p class="text-justify pe-md-8 pe-lg-11 pb-3">
    Alerts can contain a button to associate an action with the text
  </p>
  <div class="ax-example p-md-3 border text-center">
    <div class="alert alert-primary py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-secondary py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-success py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-danger py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-warning py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-info py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-light py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-dark py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert text-white bg-axa-teal" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
  </div>
  <div class="pb-4">

  ```html
   <div class="alert alert-primary py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-secondary py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-success py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-danger py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-warning py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-info py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-light py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert alert-dark py-1" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
    <div class="alert text-white bg-axa-teal" role="alert">
      A new version of MyAXA app is available on the Android & Apple
      Store<button type="button" class="ms-3 btn btn-sm">
        get it for free
      </button>
    </div>
  ```
  
  </div>
 
 
