---
layout: getting-started
title: Welcome to the AXA Design System Library
description: Its purpose is to deliver every components and styles you need to kickstart your web project. For more informations about design principles and guidelines go to <a href="https://designsystem.axa.com">designsystem.axa.com </a>.
section: Introduction
menuSlug: introduction
disableUseCase : True
---
 
<h2 class="mt-8">Compiled CSS and JS</h2>
<p class="mt-3">
  Download ready-to-use compiled code for AXA Design System
  Library to easily drop into your project, which includes:
</p>
<ul>
  <li>
    Compiled and minified CSS bundles (see CSS files comparison)
  </li>
  <li>
    Compiled and minified JavaScript plugins (see JS files
    comparison)
  </li>
  <li>Icons fonts and SourceSansPro fonts</li>
</ul>
<p>
  This doesn’t include documentation, source files, and
  <a href="#goto-alertpublico">Publico Headline Bold</a> font.
  <br />
  Go to <a href="#goto-quickStart">Quick start section</a> to know
  how to use it.
</p> 
  
<a href="{{< siteurl >}}downloadfiles/DesignSystemLib_v1.0.0.zip" class="btn btn-primary"
onclick=" window.gtag('event', 'download', {'event_category': 'Library','event_label': 'Library','value': 'v1.0'});" > Download the Build </a>

<h2 class="mt-8">Source files</h2>
<p class="mt-3">
  Compile AXA Design System Library with your own asset pipeline
  by downloading our source Sass, JavaScript, and documentation
  files. This option requires some additional tooling:
</p>
<ul>
  <li>
    Sass compiler for compiling Sass source files into CSS files
  </li>
  <li>Autoprefixer for CSS vendor prefixing</li>
</ul>
<p>
  This doesn’t include
  <a href="#goto-alertpublico">Publico Headline Bold</a> font.
  <br />
  Should you require our full set of build tools, they are
  included for developing AXA Design System Library and its docs,
  but they’re likely unsuitable for your own purposes.
</p> 

<a href="{{< siteurl >}}downloadfiles/DesignSystemLib_sources_v1.0.0.zip"
class="btn btn-primary"
onclick=" window.gtag('event', 'download', {'event_category': 'Library','event_label': 'Library','value': 'v1.0'});" > Download source 
</a>

<div id="goto-alertpublico" class="alert alert-warning mt-4 d-sm-flex" role="alert">
  <div class="text-center">
    <i class="icon-error_outline valign-btn-icon fs-xl me-3"></i>
  </div>
  <div>
    <strong>Publico Headline</strong> font is not available in the
    build and sources. It is required for typography Displays. To
    use it, entities have to purchase it directly on
    <a
      href="https://commercialtype.com/catalog/publico"
      class="text-dark text-underline"
      style="text-decoration: underline"
      target="_blank"
      rel="noopener noreferrer"
      >Commercial Type Foundry's website</a
    >. You will only need to purchase the 'bold' style, for
    further information please send a request through the Help
    &amp; Support page. <br /><br />
    When done, copy the font in woff and woff2 format in ./fonts
    folder build with file names:<br />
    PublicoHeadline-Bold.woff<br />
    PublicoHeadline-Bold.woff2
  </div>
</div>

<div id="goto-quickStart" class="display-5 pt-4 pb-1">
  Quick start
</div>
<div class="h1 pt-1">Stylesheet</div>
<p class="">
  Copy-paste the stylesheets <code>&lt;link&gt;</code> into your
  <code>&lt;head&gt;</code> before all other stylesheets to load
  our CSS.
  <br />
  Check & update the path to the files if required.
</p>

<div class="pb-1"> 

  ```html
  <link rel="stylesheet" href="./css/axaDesignSystemLib.css">
  <link rel="stylesheet" href="./css/axaDesignSystemFonts.css">
  <link rel="stylesheet" href="./css/axaIconFont.css">
  ``` 
</div>
 
<p>
  You may have to update <code>src</code> paths in
  <code>@font-face</code> within files
  <code>axaDesignSystemFonts.css</code> &
  <code>axaIconFont.css</code>
  <br />
  The minified versions of the stylesheets are also available in
  the build (<code>axaDesignSystemLib.min.css</code>
  <code>axaDesignSystemFonts.min.css</code>
  <code>axaIconFont.min.css</code>)
</p>

<div class="h1 pt-1">JavaScript</div>

<p>
  Many of components require the use of JavaScript to function.
  Specifically, they require our own JavaScript plugins and
  <a target="_blank" href="https://popper.js.org/">Popper</a>.
</p>

<p>
  Place one of the following <code>&lt;script&gt;</code>'s near the
  end of your pages, right before the closing
  <code>&lt;body&gt;</code> tag, to enable them.
</p>

<div class="h2 pt-1">Bundle</div>
<p>
  <code>axaDesignSystemLib.bundle.js</code> and
  <code>axaDesignSystemLib.bundle.min.js</code> include Popper
  (used for Tooltips an Popovers components)
</p>

<div class="pb-1">

  ```html
  <script src="stylesheet" href="./js/axaDesignSystemLib.bundle.min.js"></script>
  ```
   
</div>

<div class="h2 pt-1">Separate</div>

<div class="pb-1"> 

  ```html
  <script src="stylesheet" href="./js/popper/popper.min.js"></script>
  <script src="stylesheet" href="./js/axaDesignSystemLib.min.js"></script>
  ```  

</div> 
