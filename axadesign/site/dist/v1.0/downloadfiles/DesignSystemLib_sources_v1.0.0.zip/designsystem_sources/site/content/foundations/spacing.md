---
layout: foundations
title: Spacing
description: Includes a wide range of shorthand responsive margin and padding utility classes to modify an element’s appearance.  
section: Foundations
bootstrapRef: https://getbootstrap.com/docs/5.1/utilities/spacing/
menuSlug: spacing
---


<div class="display-5 pt-md-8 pb-1">Spacing option</div>
<p class="text-justify pe-md-8 pe-lg-11">
  AXA classes are built from a default Sass map ranging from 0.5rem to 5rem.
</p>
<p class="text-justify pe-md-8 pe-lg-11 pb-4">
  The classes are named using the format
  <code>{property}{sides}-{size}</code> for <code>xs</code> and
  <code>{property}{sides}-{breakpoint}-{size}</code> for <code>sm</code>,
  <code>md</code>, <code>lg</code>, <code>xl</code>, and <code>xxl</code>.
</p>
<p>Where <em>size</em> is one of:</p>
<ul>
  <li>
    <code>0</code> - for classes that eliminate the <code>margin</code> or
    <code>padding</code> by setting it to
    <code>0</code>
  </li>
  <li>
    <code>1</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * .5</code>
  </li>
  <li>
    <code>2</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * .75</code>
  </li>
  <li>
    <code>3</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer</code>
  </li>
  <li>
    <code>4</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * 1.5</code>
  </li>
  <li>
    <code>5</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * 2</code>
  </li>
  <li>
    <code>6</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * 2.5</code>
  </li>
  <li>
    <code>7</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * 3</code>
  </li>
  <li>
    <code>8</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * 3.5</code>
  </li>
  <li>
    <code>9</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * 4</code>
  </li>
  <li>
    <code>10</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * 4.5</code>
  </li>
  <li>
    <code>11</code> - (by default) for classes that set the
    <code>margin</code> or <code>padding</code> to
    <code>$spacer * 5</code>
  </li>
  <li>
    <code>auto</code> - for classes that set the <code>margin</code> to auto
  </li>
</ul>

<div class="display-5 pt-md-8 pb-1">Examples</div>
<p class="text-justify pe-md-8 pe-lg-11">
  Here are some representative examples of these classes:
</p>

<div class="pb-4">

  ```css
  .mt-0 { margin-top: 0 !important; } 
  .ms-1 { margin-left: ($spacer * .5) !important; } 
  .px-2 { padding-left: ($spacer * .75) !important; padding-right: ($spacer * .75) !important; } 
  .pe-11 { padding-right: ($spacer * 5) !important; } 
  .p-3 { padding: $spacer !important; } 
  ```
</div>

<div>
  <p class="ps-11 border">
    Sample test with new AXA spacer ps-11 / padding left = ($spacer * 5) = 80px
  </p>
</div>
<div class="pb-4">

  ```html
  <p class="ps-11">
    Sample test with new AXA spacer ps-11 / padding left = ($spacer * 5) = 80px
  </p>
  ```
</div>
