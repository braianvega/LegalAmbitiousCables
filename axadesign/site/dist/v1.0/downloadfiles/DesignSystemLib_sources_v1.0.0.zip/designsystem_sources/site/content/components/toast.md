---
layout: components
title: Toast
description: A push notification that appears at the bottom of the screen and
    provides information, feedback, alert on the outcome of an
    action without interrupting the user experience.
section: Components
bootstrapRef: https://getbootstrap.com/docs/5.1/components/toasts/
menuSlug: toast
---
 
  <div class="display-5 pt-md-8 pb-1">Examples</div>
  <!-- #region components_toast - examples - basic -->
  <div class="h1 pb-1 text-capitalize">basic</div>
  <div class="ax-example p-md-3 border" id="basictoast">
    <div
      class="toast fade show"
      role="alert"
      aria-live="assertive"
      aria-atomic="true"
    >
      <div class="toast-header">
        <svg
          class="me-2"
          width="20"
          height="20"
          xmlns="http://www.w3.org/2000/svg"
          role="img"
          aria-label="blue square"
          preserveAspectRatio="xMidYMid slice"
          focusable="false"
        >  <title></title> <rect width="100%" height="100%" fill="#00008f"></rect> </svg>
        <h2 class="me-auto mb-0">Toast</h2>
        11 mins ago
        <button
          type="button"
          class="ms-2 btn-close"
          data-bs-dismiss="toast"
          aria-label="Close"
        ></button>
      </div>
      <div class="toast-body">
        Hello, world! This is a toast message.
      </div>
    </div>
  </div>
  <div class="pb-4">

```html
<div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
  <div class="toast-header">
    <svg class="me-2" width="20" height="20" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="blue square" preserveAspectRatio="xMidYMid slice" focusable="false"><title> </title><rect width="100%" height="100%" fill="#00008f"></rect></svg>

    <h2 class="“me-auto" mb-0”>Toast</h2>
    11 mins ago
    <button
      type="“button”"
      class="“ms-2"
      btn-close”
      data-bs-dismiss="“toast”"
      aria-label="“Close”"
    ></button>
  </div>
  <div class="“toast-body”">
    Hello, world! This is a toast message.
  </div>
</div>


```
  </div>
  <!-- #endregion components_toast - examples - basic -->
  <!-- #region components_toast - examples - live -->
  <div class="h1 pb-1 text-capitalize">live</div>
  <div class="ax-example p-md-3 border">
    <button type="button" class="btn btn-primary" id="liveToastBtn">
      Show live toast
    </button>
    <div
      class="position-fixed bottom-0 right-0 p-3"
      style="z-index: 5; right: 0; bottom: 0"
    >
      <div
        id="liveToast"
        class="toast hide"
        role="alert"
        aria-live="assertive"
        aria-atomic="true"
        data-delay="4000"
      >
        <div class="toast-header">
          <svg
            class="me-2"
            width="20"
            height="20"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            aria-label="blue square"
            preserveAspectRatio="xMidYMid slice"
            focusable="false"
          > <title></title> <rect width="100%" height="100%" fill="#00008f"></rect> </svg>
          <h2 class="me-auto mb-0">Toast</h2>
          11 mins ago
          <button
            type="button"
            class="ms-2 btn-close"
            data-bs-dismiss="toast"
            aria-label="Close"
          ></button>
        </div>
        <div class="toast-body">
          Hello, world! This is a toast message.
        </div>
      </div>
    </div>
  </div>
  <div class="pb-4">

  
```html
<button type="button" class="btn btn-primary" id="liveToastBtn">
  Show live toast
</button>
<div
  class="position-fixed bottom-0 right-0 p-3"
  style="z-index: 5; right: 0; bottom: 0"
>
  <div
    id="liveToast"
    class="toast hide"
    role="alert"
    aria-live="assertive"
    aria-atomic="true"
    data-delay="4000"
  >
    <div class="toast-header">
      <svg class="me-2" width="20" height="20" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="blue square" preserveAspectRatio="xMidYMid slice" focusable="false"><title> </title><rect width="100%" height="100%" fill="#00008f"></rect></svg>

      <h2 class="me-auto mb-0">Toast</h2>
      11 mins ago
      <button
        type="button"
        class="ms-2 btn-close"
        data-bs-dismiss="toast"
        aria-label="Close"
      ></button>
    </div>
    <div class="toast-body">
      Hello, world! This is a toast message.
    </div>
  </div>
</div>  

```

```html
<!-- script to add after loading axaDesignSystemLib js dependencie -->
<script>
// Enable toast
var toastTrigger = document.getElementById('liveToastBtn')
var toastLiveExample = document.getElementById('liveToast')
if (toastTrigger) {
  toastTrigger.addEventListener('click', function () {
    var toast = new axalib.Toast(toastLiveExample)
    toast.show()
  })
}
</script> 
```
</div>
 