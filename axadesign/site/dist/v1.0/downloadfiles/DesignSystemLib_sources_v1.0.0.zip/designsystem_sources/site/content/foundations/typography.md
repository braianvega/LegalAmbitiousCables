---
layout: foundations
title: Typography
description: Documentation and examples for typography, including global settings, headings, body text, lists, and more. Source Sans Pro and Publico Headline are the two typefaces to be used on all AXA digital assets.
section: Foundations
bootstrapRef: https://getbootstrap.com/docs/5.1/content/typography/
menuSlug: typography
---

<!-- #region CONTENT - TYPOGRAPHY - DISPLAY -->
<div class="display-5 pt-md-8 pb-1">Display</div>
<p class="text-justify pe-md-8 pe-lg-11 pb-3">
  Publico Headline Bold is a the typeface with personality and
  emotion. It is used in bold for main messages and headlines and
  creates contrast. Coupled with Source Sans Pro it enhances the
  design by adding rythm, creating a clear hierarchy and providing
  a strong visual identity.
</p>
<table class="table table-borderless text-justify bg-warning text-white">
  <tbody>
    <tr>
      <td>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="#fff" viewBox="0 0 12 12" > <circle cx="6" cy="6" r="4.5"/> <path stroke-linejoin="round" d="M5.8 3.6h.4L6 6.5z"/> <circle cx="6" cy="8.2" r=".6" fill="#fff" stroke="none"/> </svg>
      </td>
      <td>
        As for <strong>Publico Headline</strong>, entities have to
        purchase it directly on
        <a
          href="https://commercialtype.com/catalog/publico"
          class="text-light text-underline"
          style="text-decoration: underline"
          target="_blank"
          rel="noopener noreferrer"
          >Commercial Type Foundry's website</a
        >. You will only need to purchase the 'bold' style, for
        further information please send a request through the Help
        & Support page.
      </td>
    </tr>
  </tbody>
</table>

<div class="ax-example p-md-3 border">
  <p><span class="display-1">Display 1</span></p>
  <p><span class="display-2">Display 2</span></p>
  <p><span class="display-3">Display 3</span></p>
  <p><span class="display-4">Display 4</span></p>
  <p><span class="display-5">Display 5</span></p>
  <p><span class="display-6">Display 6</span></p>
</div>
<div class="pb-4">

```html
<span class="display-1">Display 1</span>
<span class="display-2">Display 2</span>
<span class="display-3">Display 3</span>
<span class="display-4">Display 4</span>
<span class="display-5">Display 5</span>
<span class="display-6">Display 6</span>
```

</div>
<!-- #endregion CONTENT - TYPOGRAPHY - DISPLAY -->

<!-- #region CONTENT - TYPOGRAPHY - HEADINGS -->
<div class="display-5 pt-md-8 pb-1">Headings</div>
<p class="text-justify pe-md-8 pe-lg-11 pb-4">
  HTML headings, <code>&lt;h1&gt;</code> through
  <code>&lt;h5&gt;</code>, are available.
</p>
<div class="ax-example p-md-3 border">
  <h1>h1. AXA Heading</h1>
  <h2>h2. AXA Heading</h2>
  <h3>h3. AXA Heading</h3>
  <h4>h4. AXA Heading</h4>
  <h5>h5. AXA Heading</h5>
</div>
<div class="pb-4">

```html
<h1>h1. AXA Heading</h1>
<h2>h2. AXA Heading</h2>
<h3>h3. AXA Heading</h3>
<h4>h4. AXA Heading</h4>
<h5>h5. AXA Heading</h5>
```

</div>
<div class="ax-example p-md-3 border">
  <p class="h1">h1. AXA Heading</p>
  <p class="h2">h2. AXA Heading</p>
  <p class="h3">h3. AXA Heading</p>
  <p class="h4">h4. AXA Heading</p>
  <p class="h5">h5. AXA Heading</p>
</div>
<div class="pb-4">

```html
<p class="h1">h1. AXA Heading</p>
<p class="h2">h2. AXA Heading</p>
<p class="h3">h3. AXA Heading</p>
<p class="h4">h4. AXA Heading</p>
<p class="h5">h5. AXA Heading</p>
```

</div>
<!-- #endregion CONTENT - TYPOGRAPHY - HEADINGS -->

<!-- #region CONTENT - TYPOGRAPHY - BLOCKQUOTE -->
<div class="display-5 pt-md-8 pb-1">Blockquotes</div>
<p class="text-justify pe-md-8 pe-lg-11 pb-4">
  For quoting blocks of content from another source within your
  document. Wrap
  <code>&lt;blockquote class="blockquote"&gt;</code> around any
  HTML as the quote. <br /><br />
  Add a <code>&lt;footer class="blockquote-footer"&gt;</code> for
  identifying the source. Wrap the name of the source work in
  <code>&lt;cite&gt;</code>.
</p>
<div class="ax-example p-md-3 border">
  <blockquote class="blockquote">
    <p class="mb-0">A quote, contained in a blockquote</p>
  </blockquote>
</div>
<div class="pb-4">

```html
<blockquote class="blockquote">
  <p class="mb-0">A quote, contained in a blockquote</p>
</blockquote>
```

</div>

<div class="ax-example p-md-3 border">
  <blockquote class="blockquote">
    <p class="mb-0">A quote, contained in a blockquote</p>
    <footer class="blockquote-footer">
      Someone famous in
      <cite title="Source Title">Source Title</cite>
    </footer>
  </blockquote>
</div>
<div class="pb-4">

```html
<blockquote class="blockquote">
  <p class="mb-0">A quote, contained in a blockquote</p>
  <footer class="blockquote-footer">
    Someone famous in
    <cite title="Source Title">Source Title</cite>
  </footer>
</blockquote>
```

</div>

<!-- #endregion CONTENT - TYPOGRAPHY - BLOCKQUOTE -->

<!-- #region CONTENT - TYPOGRAPHY - PARAGRAPH -->
<div class="display-5 pt-md-8 pb-1">Paragraph</div>
<p class="text-justify pe-md-8 pe-lg-11 pb-4">
  Source Sans Pro is a sans serif typeface that has been chosen to
  transition from ITC Franklin Gothic and Metric as it works
  pretty well in all user interfaces, covers a large spectrum of
  signs and has no cost.
</p>
<div class="ax-example p-md-3 border">
  <p>This is a paragraph</p>
  <p><strong>This is a paragraph</strong></p>
  <p class="lead">This is a lead paragraph.</p>
  <p class="lead">
    <strong>This is a lead paragraph with bold font.</strong>
  </p>
  <p><small>This is a paragraph</small></p>
</div>
<div class="pb-4">

```html
<p>This is a paragraph</p>
<p><strong>This is a paragraph</strong></p>
<p class="lead">This is a lead paragraph.</p>
<p class="lead">
  <strong>This is a lead paragraph with bold font.</strong>
</p>
<p><small>This is a paragraph</small></p>
```

</div>
<!-- #endregion CONTENT - TYPOGRAPHY - PARAGRAPH -->

<!-- #region CONTENT - TYPOGRAPHY - LINKS -->
<div class="display-5 pt-md-8 pb-1">Links</div>

<p class="text-justify pe-md-8 pe-lg-11 pb-4">
  Link style use in AXA Design System.
</p>

<div class="ax-example p-md-3 border">
  <a href="#typo_lnk_part" id="typo_lnk_part">This is a link</a>
</div>

<div class="pb-4">

```html
<a href="#typo_lnk_part" id="typo_lnk_part">This is a link</a>
```

</div>
<!-- #endregion CONTENT - TYPOGRAPHY - LINKS -->
