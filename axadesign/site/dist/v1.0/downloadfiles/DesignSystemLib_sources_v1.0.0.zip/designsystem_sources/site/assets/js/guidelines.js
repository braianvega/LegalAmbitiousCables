
window.displayTechDoc = function displayTechDoc(section){
  event.preventDefault();

  // Fix of the bug present in current version library
  document.getElementById(`selection_${section}-tech`) && document.getElementById(`selection_${section}-tech`).classList.add('active');
  document.getElementById(`selection_${section}-guidelines`) && document.getElementById(`selection_${section}-guidelines`).classList.remove('active');
  
  // Change the view of the page to design guidelines
  document.getElementById(`foundations_${section}-guidelines`).style.display = 'none';
  document.getElementById(`foundations_${section}-tech`).style.display = 'block';
}

window.displayGuidelines = function displayGuidelines(section) {
  event.preventDefault();
  // Fix of the bug present in current version library
  document.getElementById(`selection_${section}-tech`) && document.getElementById(`selection_${section}-tech`).classList.remove('active');
  document.getElementById(`selection_${section}-guidelines`) && document.getElementById(`selection_${section}-guidelines`).classList.add('active');
  // Change the view of the page to design guidelines
  document.getElementById(`foundations_${section}-guidelines`).style.display = 'block';
  document.getElementById(`foundations_${section}-tech`).style.display = 'none';
  
    // Get the queryParams to check if we are in preview mode
    if((navigator.userAgent.indexOf("MSIE") !== -1 ) || (!!document.documentMode === true )) { //IF IE > 10
      document.getElementById(`foundations_${section}-guidelines`).innerHTML= `
      <div class="mt-8">
        <p>This feature is not supported on IE 11. Please open the library in another browser.</p>
      </div>
      `
    } else {
      let sectionGuidelines = document.getElementById(`body_${section}-guidelines`)
      console.log(sectionGuidelines)
    
      if (!sectionGuidelines){
        // Display spinner until the response is displayed
        document.getElementById(`foundations_${section}-guidelines`).innerHTML= `
        <div class="spinner-border text-primary mt-6" role="status" data-testid="spinner_loading">
          <span class="visually-hidden">Loading...</span>
        </div>
        `

        const params = URLSearchParams ? new URLSearchParams(window.location.search) : null;
        const token = params ? params.get("token") : "notSupported";
        const documentId = params ? params.get("documentId") : "notSupported";
        console.log(token, documentId);
      

      // Get the data for the design guidelines section
      (token ? 
      fetch(process.env.GUIDELINES_API_URL ? 
        `${process.env.GUIDELINES_API_URL}/api/preview/${encodeURIComponent(token)}/${documentId}` 
        : `/api/preview/${encodeURIComponent(token)}/${documentId}`)
      :
      fetch(process.env.GUIDELINES_API_URL ?
        `${process.env.GUIDELINES_API_URL}/api/getDesignLibComponentByUID/${section}` 
        : `/api/getDesignLibComponentByUID/${section}`)
      )
      .then(response => response.json())
      .then(response => {
        console.log('this is the response if taken into account')
        if (response) {
          let designGuidelines="";
          let data = response.data ? response.data.body : response.dataPreview.data.body
          data.map((item)=>{
            switch (item.slice_type) {
              // Display the different options from the slice zone
              case 'title': // TITLE SECTION
              designGuidelines = designGuidelines + `<h2 class=${item.primary.title[0].type === "heading1" ? "display-5 mb-5" : "mb-1"}>${item.primary.title[0].text}</h2> `
              break;
              case 'paragraph': // PARAGRAPH SECTION
              item.items.map((paragraph)=>{
                designGuidelines = designGuidelines + `<p>${paragraph.paragraph[0].text}</p>`
              })
              break;
              case 'image': // IMAGE SECTION
              designGuidelines = designGuidelines + `<div className="mb-5 px-0 px-md-2">
                          <img 
                            src=${item.primary.image.url} 
                            alt=${item.primary.image.alt}
                            style=${item.primary.keep_original_size ? "maxWidth:100%":"width:100%"} />
                        </div>`
              break;
              case 'link': // LINK SECTION
                designGuidelines = designGuidelines + `<div className="px-md-2 px-0 m-auto text-center pb-6">
                          <a href=${item.primary.link.url}>
                            ${item.primary.link_placeholder ? 
                              item.primary.link_placeholder[0].text
                              : item.primary.link.url}</a>
                        </div>`
              break;
              case 'video': // VIDEO SECTION
                designGuidelines = designGuidelines + `<div class="pb-5" style="width:100%;height:${item.items[0].video.thumbnail_height}px;object-fit:contain"}}/>
                  ${item.items[0].video.html}
                </div>`
              break;
              default:
            }
          })
        // Insert the element in the virtual DOM of the page
        document.getElementById(`foundations_${section}-guidelines`).innerHTML= `
          <div class="mt-6" id=${`body_${section}-guidelines`}>
            ${designGuidelines}
          </div>`
        } else {
        console.warn('an issue occured with the import of the content');
        }
      })
      .catch(error => {
        console.error("error", error);
      })
    }
  }
}