---
layout: components
title: Buttons-group
description: Button Group gathers a serie of content together on a single line.
section: Components
bootstrapRef: https://getbootstrap.com/docs/5.1/components/button-group/
menuSlug: buttons-group
---

<!-- #region components_buttons_group - examples -->
<div class="display-5 pt-md-8 pb-1">Examples</div>
<p class="text-justify pe-md-8 pe-lg-11 pb-3">
  You can combine several types of buttons together like a button
  with only one icon.
</p>
<div class="ax-example p-md-3 border">
  <div class="row mb-3">
    <div class="col text-center">
      <div  class="btn-group" role="group" aria-label="Basic example" >
        <button type="button" class="btn btn-primary border-end">
          make a call
        </button>
        <button type="button" class="btn btn-primary">
          <i class="icon-call valign-btn-icon"></i>
        </button>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col text-center">
     <div class="btn-group" role="group" aria-label="Basic example" >
    <button type="button" class="btn btn-secondary border-end" >
      schedule an appointment
    </button>
    <button type="button" class="btn btn-secondary">
      <i class="icon-calendar valign-btn-icon"></i>
    </button>
    </div>
    </div>
  </div>
</div>

<div class="pb-4">
  
```html 
<div class="btn-group" role="group" aria-label="Basic example">
  <button type="button" class="btn btn-primary border-end">make a call</button>
  <button type="button" class="btn btn-primary">
    <i class="icon-call"></i>
  </button>
</div>
<div class="btn-group" role="group" aria-label="Basic example">
  <button type="button" class="btn btn-secondary border-end">schedule an appointment</button>
  <button type="button" class="btn btn-secondary">
    <i class="icon-calendar"></i>
  </button>
</div>

```
</div>


```
