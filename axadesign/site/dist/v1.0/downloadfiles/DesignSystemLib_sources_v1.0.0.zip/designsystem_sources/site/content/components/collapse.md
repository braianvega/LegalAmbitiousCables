---
layout: components
title: Collapse
description: A good way to display a long section of content by hiding it or
  revealing under a block thanks to the action of the user. This
  is mainly used for secondary content and it’s important to avoid
  hiding important information into this block.
section: Components
bootstrapRef: https://getbootstrap.com/docs/5.1/components/collapse/
menuSlug: collapse
---

  <div class="display-5 pt-md-8 pb-1">Example</div>
  <div class="ax-example p-md-3 border">
    <p>
      <a
        class="btn btn-primary me-1 mb-md-0 mb-1"
        data-bs-toggle="collapse"
        href="#collapseExample"
        role="button"
        aria-expanded="false"
        aria-controls="collapseExample"
      >
        Link with href
      </a>
      <button
        class="btn btn-primary mb-md-0 mb-1"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#collapseExample"
        aria-expanded="false"
        aria-controls="collapseExample"
      >
        Button with data-bs-target
      </button>
    </p>
    <div class="collapse" id="collapseExample">
      <div class="border py-4 px-3">
        Some placeholder content for the collapse component. This
        panel is hidden by default but revealed when the user
        activates the relevant trigger.
      </div>
    </div>
  </div>

  <div class="pb-4">
      
  ```html 
  <p>
    <a
      class="btn btn-primary"
      data-bs-toggle="collapse"
      href="#collapseExample"
      role="button"
      aria-expanded="false"
      aria-controls="collapseExample"
    >
      Link with href
    </a>
    <button
      class="btn btn-primary"
      type="button"
      data-bs-toggle="collapse"
      data-bs-target="#collapseExample"
      aria-expanded="false"
      aria-controls="collapseExample"
    >
      Button with data-bs-target
    </button>
  </p>
  <div class="collapse" id="collapseExample">
    <div class="card card-body">
      Some placeholder content for the collapse component. This panel is hidden by
      default but revealed when the user activates the relevant trigger.
    </div>
  </div> 
  ```

  </div>
  
  <div class="display-5 pt-md-8 pb-1">Multiple targets</div>
  <p class="text-justify pe-md-8 pe-lg-11 pb-3">
    The buttons can also open several targets depending on the
    content.
  </p>
  <div class="ax-example p-md-3 border">
    <p>
      <a
        class="btn btn-primary"
        data-bs-toggle="collapse"
        href="#multiCollapseExample1"
        role="button"
        aria-expanded="false"
        aria-controls="multiCollapseExample1"
        >Toggle first element</a
      >
      <button
        class="btn btn-primary"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#multiCollapseExample2"
        aria-expanded="false"
        aria-controls="multiCollapseExample2"
      >
        Toggle second element
      </button>
      <button
        class="btn btn-primary"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target=".multi-collapse"
        aria-expanded="false"
        aria-controls="multiCollapseExample1 multiCollapseExample2"
      >
        Toggle both elements
      </button>
    </p>
    <div class="row">
      <div class="col">
        <div
          class="collapse multi-collapse"
          id="multiCollapseExample1"
        >
          <div class="border py-4 px-3">
            Some placeholder content for the first collapse
            component of this multi-collapse example. This panel is
            hidden by default but revealed when the user activates
            the relevant trigger.
          </div>
        </div>
      </div>
      <div class="col">
        <div
          class="collapse multi-collapse"
          id="multiCollapseExample2"
        >
          <div class="border py-4 px-3">
            Some placeholder content for the second collapse
            component of this multi-collapse example. This panel is
            hidden by default but revealed when the user activates
            the relevant trigger.
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="pb-4">

```html
<p>
  <a
    class="btn btn-primary"
    data-bs-toggle="collapse"
    href="#multiCollapseExample1"
    role="button"
    aria-expanded="false"
    aria-controls="multiCollapseExample1"
    >Toggle first element</a
  >
  <button
    class="btn btn-primary"
    type="button"
    data-bs-toggle="collapse"
    data-bs-target="#multiCollapseExample2"
    aria-expanded="false"
    aria-controls="multiCollapseExample2"
  >
    Toggle second element
  </button>
  <button
    class="btn btn-primary"
    type="button"
    data-bs-toggle="collapse"
    data-bs-target=".multi-collapse"
    aria-expanded="false"
    aria-controls="multiCollapseExample1 multiCollapseExample2"
  >
    Toggle both elements
  </button>
</p>
<div class="row">
  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample1">
      <div class="border py-4 px-3">
        Some placeholder content for the first collapse component of this
        multi-collapse example. This panel is hidden by default but revealed
        when the user activates the relevant trigger.
      </div>
    </div>
  </div>
  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample2">
      <div class="border py-4 px-3">
        Some placeholder content for the second collapse component of this
        multi-collapse example. This panel is hidden by default but revealed
        when the user activates the relevant trigger.
      </div>
    </div>
  </div>
</div>
```

  </div>
  <!-- #endregion components_collapse - multiple targets -->
  <!-- #region components_collapse - accordion example -->
  <div class="display-5 pt-md-8 pb-1">Accordion example</div>
  <p class="text-justify pe-md-8 pe-lg-11 pb-3">
    A more classic accordion version with disclosure to maximise
    space and display information only when requested by the user.
  </p>
  <div class="ax-example p-md-3 border">
    <div class="accordion" id="accordionExample">
      <div class="accordion-item">
        <div class="accordion-header" id="headingOne">
          <button
            class="btn accordion-button"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#collapseOne"
            aria-expanded="true"
            aria-controls="collapseOne"
          >
            ACCORDION ITEM #1
          </button>
        </div>
        <div
          id="collapseOne"
          class="accordion-collapse collapse show"
          aria-labelledby="headingOne"
          data-bs-parent="#accordionExample"
        >
          <div class="accordion-body">
            Some placeholder content for the first accordion panel.
            This panel is shown by default, thanks to the
            <code>.show</code> class.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <div class="accordion-header" id="headingTwo">
          <button
            class="btn accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#collapseTwo"
            aria-expanded="false"
            aria-controls="collapseTwo"
          >
            ACCORDION ITEM #2
          </button>
        </div>
        <div
          id="collapseTwo"
          class="accordion-collapse collapse"
          aria-labelledby="headingTwo"
          data-bs-parent="#accordionExample"
        >
          <div class="accordion-body">
            Some placeholder content for the second accordion panel.
            This panel is hidden by default.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <div class="accordion-header" id="headingThree">
          <button
            class="btn accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#collapseThree"
            aria-expanded="false"
            aria-controls="collapseThree"
          >
            ACCORDION ITEM #3
          </button>
        </div>
        <div
          id="collapseThree"
          class="accordion-collapse collapse"
          aria-labelledby="headingThree"
          data-bs-parent="#accordionExample"
        >
          <div class="accordion-body">
            Some placeholder content for the second accordion panel.
            This panel is hidden by default.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <div class="accordion-header" id="headingFour">
          <button
            class="btn accordion-button collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#collapseFour"
            aria-expanded="false"
            aria-controls="collapseFour"
            disabled
          >
            ACCORDION ITEM #4 (DISABLED)
          </button>
        </div>
        <div
          id="collapseFour"
          class="accordion-collapse collapse"
          aria-labelledby="headingFour"
          data-bs-parent="#accordionExample"
        >
          <div class="accordion-body">
            Some placeholder content for the second accordion panel.
            This panel is hidden by default.
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="pb-4">
   
```html 
<div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
      <button
        class="btn accordion-button"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#collapseOne"
        aria-expanded="true"
        aria-controls="collapseOne"
      >
        ACCORDION ITEM #1
      </button>
    </h2>
    <div
      id="collapseOne"
      class="accordion-collapse collapse show"
      aria-labelledby="headingOne"
      data-bs-parent="#accordionExample"
    >
      <div class="accordion-body">
        Some placeholder content for the first accordion panel. This panel is
        shown by default, thanks to the code.show/code class.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
      <button
        class="btn accordion-button collapsed"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#collapseTwo"
        aria-expanded="false"
        aria-controls="collapseTwo"
      >
        ACCORDION ITEM #2
      </button>
    </h2>
    <div
      id="collapseTwo"
      class="accordion-collapse collapse"
      aria-labelledby="headingTwo"
      data-bs-parent="#accordionExample"
    >
      <div class="accordion-body">
        Some placeholder content for the second accordion panel. This panel is
        hidden by default.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button
        class="btn accordion-button collapsed"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#collapseThree"
        aria-expanded="false"
        aria-controls="collapseThree"
      >
        ACCORDION ITEM #3
      </button>
    </h2>
    <div
      id="collapseThree"
      class="accordion-collapse collapse"
      aria-labelledby="headingThree"
      data-bs-parent="#accordionExample"
    >
      <div class="accordion-body">
        Some placeholder content for the second accordion panel. This panel is
        hidden by default.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingFour">
      <button
        class="btn accordion-button collapsed"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#collapseFour"
        aria-expanded="false"
        aria-controls="collapseFour"
        disabled
      >
        ACCORDION ITEM #4 (DISABLED)
      </button>
    </h2>
    <div
      id="collapseFour"
      class="accordion-collapse collapse"
      aria-labelledby="headingFour"
      data-bs-parent="#accordionExample"
    >
      <div class="accordion-body">
        Some placeholder content for the second accordion panel. This panel is
        hidden by default.
      </div>
    </div>
  </div>
</div> 

```
</div>
 
